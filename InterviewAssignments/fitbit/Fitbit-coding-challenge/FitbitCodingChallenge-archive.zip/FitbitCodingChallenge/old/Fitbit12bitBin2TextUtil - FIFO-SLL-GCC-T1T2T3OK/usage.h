#ifndef _FITBIT12BITBIN2TEXTUTIL_USAGE_H_
#define _FITBIT12BITBIN2TEXTUTIL_USAGE_H_

/* usage dumps usage info to console.
** Arguments:
**  executableName[]:	Char array containing the first element from argv, the 
**                      executable name.
*/
void Usage(const char* executableName);

#endif /* _FITBIT12BITBIN2TEXTUTIL_USAGE_H_ */
