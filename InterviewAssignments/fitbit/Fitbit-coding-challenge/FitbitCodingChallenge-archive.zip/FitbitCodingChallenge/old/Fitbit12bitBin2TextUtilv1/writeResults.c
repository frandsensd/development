#include <stdio.h>
#include "types.h"
#include "fifoBuffer.h"
#include "writeResults.h"
#include "commonDefinitions.h"


/* Implementation of writeResults per specification in header file.
** Purpose is to write a formatted text output to a text file, which has been 
** created. ** Format is specified in header file.
*/
errorcodes_t writeResults(FILE *const fOutFile, 
	const sample_t *const maxSamplesBuffer )
{
	sample_t value;
	uint8_t sample;
	int result;
	uint8_t samples = fifoBufferGetCount();

	result = fprintf(fOutFile, "--Sorted Max 32 Values--\n", samples);
	if (result < 0) {
		printf("Error: Failed writing to output file!\n");
		return result;
	}
	
	for (sample = 0; sample < samples; sample++)
	{
		result = fprintf(fOutFile, "%5d\n", maxSamplesBuffer[sample]);
		if (result < 0) {
			printf("Error: Failed writing sorted values to output file!\n");
			return result;
		}
	}

	result = fprintf(fOutFile, "--Last 32 Values--\n");
	if (result < 0) {
		printf("Error: Failed writing to output file!\n");
		return result;
	}

	while ( FIFOERROR_BUFFEREMPTY != fifoBufferRead(&value))
	{
		result = fprintf(fOutFile, "%5d\n", value);
		if (result < 0) {
			printf("Error: Failed writing FIFO content to output file!\n");
			return result;
		}
	}

	return OK;
}
