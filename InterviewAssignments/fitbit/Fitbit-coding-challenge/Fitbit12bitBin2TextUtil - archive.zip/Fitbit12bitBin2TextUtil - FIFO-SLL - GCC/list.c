#include <stdio.h>
#include <stdlib.h>
#include "types.h"
#include "commonDefinitions.h"
#include "list.h"

static uint8_t	isInitialized = FALSE;
static singlelist_t	list;

static listerrors_t listInit()
{
	list.head = (singlelistnode_t*)malloc(sizeof(singlelistnode_t));
	list.tail = (singlelistnode_t*)malloc(sizeof(singlelistnode_t));
	if (list.head != NULL && list.tail != NULL)
	{
		list.head->next = list.tail;
		list.tail->next = list.tail;
		list.elements = 0;
		isInitialized = TRUE;
		return LISTERROR_OK;
	}
	else
	{
		return LISTERROR_MEMORYALLOCATIONFAILED;
	}
}

/* listInsert inserts sample in single linked list in ordered manner
** with head always pointing to largest value in list.
*/
listerrors_t	listInsert(const sample_t sample)
{
	if (FALSE == isInitialized) {
		listInit();
	}
	/* node = first/largest element in list */
	singlelistnode_t* node = list.head->next;
	/* look for insertion point */
	while (node->sample >= sample && node->next != list.tail) {
		node = node->next;
		printf("%s: advancing node; node->sample=%d >= sample(%d)", __FUNCTION__, node->sample, sample);
	}
	/* if list is not yet full insert new sample at node->next.
	** if list is full but we're not at tail yet - insert new sample at node->next.*/
	if (list.elements < SAMPLESTOSTORE || node->next != list.tail )
	{
		singlelistnode_t* newNode = (singlelistnode_t*) malloc(sizeof(singlelistnode_t));
		if (newNode != NULL) {
			newNode->next = node->next;
			node->next = newNode;
		}
		else {
			return LISTERROR_MEMORYALLOCATIONFAILED;
		}
		printf("%s: node inserted between samples %d and %d", __FUNCTION__, node->sample, newNode->next->sample);
	}
	else
	{
		printf("%s: sample (%d) too small to be inserted. Smallest sample in list is %d", __FUNCTION__, sample, node->sample);
	}
	return LISTERROR_OK;
}

/* listPop retrieves largest value from list (element head points at),
** updates head to point to next element and deletes the element.
*/
listerrors_t	listPop(sample_t *const sample)
{
	if (FALSE == isInitialized) {
		listInit();
	}
	singlelistnode_t* nodeToPop = list.head->next;
	*sample = nodeToPop->sample;
	list.head->next = nodeToPop->next;
	free(nodeToPop);
	return LISTERROR_OK;
}

/* listGetLengh retrieves amount of nodes stored in list.
*/
listerrors_t	listGetLength(uint8_t *const length)
{
	*length = list.elements;
	return LISTERROR_OK;
}
